#' Internal tidyverse methods
#'
#' @import tidyverse
#' @keywords internal
NULL

#' Internal broom methods
#'
#' @import broom
#' @keywords internal
NULL

#' Internal gapminder methods
#'
#' @import gapminder
#' @keywords internal
NULL
#
#' Internal learnr methods
#'
#' @import learnr
#' @keywords internal
NULL
